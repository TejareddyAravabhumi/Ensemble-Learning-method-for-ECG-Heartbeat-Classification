# Importing necessary libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import plot_confusion_matrix  # New import

# Load and preprocess the dataset
df = pd.read_csv('load_ecg_data.csv')
X = df.iloc[:, :-1].values  # All columns except the last one
y = df.iloc[:, -1].values  # Only the last column

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Function to plot confusion matrix (new function)
def plot_confusion_matrix_for_classifier(clf, X_test, y_test, clf_name):
    plot_confusion_matrix(clf, X_test, y_test)
    plt.title(f'Confusion Matrix for {clf_name}')
    plt.show()

# Bagging with Random Forest
rf_clf = RandomForestClassifier(n_estimators=100, random_state=42)
rf_clf.fit(X_train, y_train)
rf_predictions = rf_clf.predict(X_test)
print(f"Random Forest accuracy: {accuracy_score(y_test, rf_predictions)}")
print(classification_report(y_test, rf_predictions))
plot_confusion_matrix_for_classifier(rf_clf, X_test, y_test, 'Random Forest')  # New line

# Boosting with AdaBoost
ab_clf = AdaBoostClassifier(n_estimators=100, random_state=42)
ab_clf.fit(X_train, y_train)
ab_predictions = ab_clf.predict(X_test)
print(f"AdaBoost accuracy: {accuracy_score(y_test, ab_predictions)}")
print(classification_report(y_test, ab_predictions))
plot_confusion_matrix_for_classifier(ab_clf, X_test, y_test, 'AdaBoost')  # New line

# Stacking with a Neural Network as Meta-Learner
base_classifiers = {
    'svm': SVC(probability=True, random_state=42),
    'knn': KNeighborsClassifier(),
    'log_reg': LogisticRegression(random_state=42)
}

meta_features_train = np.array([clf.fit(X_train, y_train).predict_proba(X_train) for clf in base_classifiers.values()]).mean(axis=0)
meta_clf = MLPClassifier(random_state=42)
meta_clf.fit(meta_features_train, y_train)
meta_features_test = np.array([clf.predict_proba(X_test) for clf in base_classifiers.values()]).mean(axis=0)
stacking_predictions = meta_clf.predict(meta_features_test)
print(f"Stacking accuracy: {accuracy_score(y_test, stacking_predictions)}")
print(classification_report(y_test, stacking_predictions))
plot_confusion_matrix_for_classifier(meta_clf, meta_features_test, y_test, 'Stacking Meta-Classifier')  # New line
